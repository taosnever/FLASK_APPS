from flask import Flask, jsonify, session, redirect, url_for, escape, request, render_template
import requests, json

app = Flask(__name__)


@app.route('/')
def home():
	return render_template('home.html')

@app.route('/home.html')
def homeHTML():
	return render_template('home.html')

@app.route('/contacto.html')
def contactoHTML():
	return render_template('contacto.html')

@app.route('/estadisticas.html')
def estadisticasHTML():
	return render_template('estadisticas.html')

@app.route('/medicion.html')
def medicionHTML():
	return render_template('medicion.html')

@app.route('/nosotros.html')
def nosotrosHTML():
	return render_template('nosotros.html')


@app.route('/rest')
def rest():
	try:
		url = 'http://meteofib.ddns.net'
		r = requests.get(url)
		return r.text

	except:
		return 'Error in REST connection'



if __name__ == '__main__':
        app.run()
