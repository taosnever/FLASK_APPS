from flask import Flask, jsonify, session, redirect, url_for, escape, request, render_template
import requests, json
from forms import ContactForm
from flask_mail import Message, Mail

mail = Mail()

app = Flask(__name__)

app.secret_key = 'development key'

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USE_SSL"] = True
app.config["MAIL_USERNAME"] = 'contacto.meteofib@gmail.com'
app.config["MAIL_PASSWORD"] = '123456789ABC'

mail.init_app(app)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/home.html')
def homeHTML():
	return render_template('home.html')

@app.route('/contacto.html', methods=['GET', 'POST'])
def contactoHTML():
	form = ContactForm()

	if request.method == 'POST':
		msg = Message(form.subject.data, sender='contacto.meteofib@gmail.com', recipients=['contacto.meteofib@gmail.com'])
		msg.body = """
		From: %s <%s>
 		%s
    		""" % (form.name.data, form.email.data, form.message.data)
    		mail.send(msg)

    		return render_template('formulario.html', success=True)

  	elif request.method == 'GET':
		return render_template('formulario.html', form=form)
	
@app.route('/estadisticas.html')
def estadisticasHTML():
	return render_template('estadisticas.html')

@app.route('/medicion.html')
def medicionHTML():
	return render_template('medicion.html')

@app.route('/nosotros.html')
def nosotrosHTML():
	return render_template('nosotros.html')

@app.route('/sub.html')
def subHTML():
	return render_template('sub.html')

@app.route('/rest')
def rest():
	try:
		url = 'http://meteofib.ddns.net'
		r = requests.get(url)
		return r.text

	except:
		return 'Error in REST connection'



if __name__ == '__main__':
        app.run()
