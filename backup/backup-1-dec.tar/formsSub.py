from flask_wtf import FlaskForm as Form
from wtforms import TextField, SubmitField, validators, TextAreaField

class SubForm(Form):
  email = TextField("Correo Electronico")

