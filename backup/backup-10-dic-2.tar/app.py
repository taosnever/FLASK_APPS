from flask import Flask, jsonify, session, redirect, url_for, escape, request, render_template
import requests, json
from forms import ContactForm, SubForm
from flask_mail import Message, Mail
from flask_pymongo import PyMongo

mail = Mail()

app = Flask(__name__)

app.secret_key = 'development key'

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USE_SSL"] = True
app.config["MAIL_USERNAME"] = 'contacto.meteofib@gmail.com'
app.config["MAIL_PASSWORD"] = '123456789ABC'

mail.init_app(app)

app.config['MONGO_DBNAME'] = 'suscripcion'

mongo = PyMongo(app)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/home.html')
def homeHTML():
	return render_template('home.html')

@app.route('/contacto.html', methods=['GET', 'POST'])
def contactoHTML():
	form = ContactForm()

	if request.method == 'POST':
		msg = Message(form.subject.data, sender='contacto.meteofib@gmail.com', recipients=['contacto.meteofib@gmail.com'])
		msg.body = """
		De: %s <%s>\n
 		%s
    		""" % (form.name.data, form.email.data, form.message.data)
    		mail.send(msg)

    		return render_template('formulario.html', success=True)

  	elif request.method == 'GET':
		return render_template('formulario.html', form=form)
	
@app.route('/estadisticas.html')
def estadisticasHTML():
	return render_template('estadisticas.html')

@app.route('/medicion.html')
def medicionHTML():
	return render_template('medicion.html')

@app.route('/nosotros.html')
def nosotrosHTML():
	return render_template('nosotros.html')

@app.route('/sub.html', methods=['GET', 'POST'])
def subHTML():
	form = SubForm()
	
	if request.method == 'POST':

		email = form.email.data
		pred = form.pred.data
		
		usuarios = mongo.db.infoUsuariosSub
    		usuarios.insert({'email' : email, 'prediccion' : pred})
				
        	return render_template('formularioSub.html', success=True)
	elif request.method == 'GET':
        	return render_template('formularioSub.html', form=form)

@app.route('/rest')
def rest():
	try:
		url = 'http://meteofib.ddns.net'
		r = requests.get(url)
		return r.text

	except:
		return 'Error in REST connection'


@app.route('/pruebaNew')
def prueba():
	us = mongo.db.infoUsuariosSub

	pepe = ""
	#for info in us.find():
#		pepe+=info
   
	#ne = us.find_one({'prediccion' : False}) 
	count = us.count()	
	
	for info in us.find():
		pepe+=info['email']
		msgSub = Message('Informe semanal MeteoFIB', sender='contacto.meteofib@gmail.com', recipients=['contacto.meteofib@gmail.com'])
		msgSub.body = """
		%s
		""" % ('Mensaje de prueba')

		if info['prediccion']:
			msgSub.body += ' (YES)'
		else:
			msgSub.body += ' (NO)'

		mail.send(msgSub)
	

	#return 'Enviado correctamente'+ str(count)+ ' !' + pepe
	return render_template('infoPredExtra.html', pred=True)

@app.route('/pruebaEmail')
def pruebaEmail():
	msgSub = Message('Informe semanal MeteoFIB', sender='contacto.meteofib@gmail.com', recipients=['contacto.meteofib@gmail.com'])
        msgSub.body = """
        <b>PEPEEEE</b>
        """
        msgSub.IsBodyHtml = True
	mail.send(msgSub)

	return 'Lihto'




if __name__ == '__main__':
        app.run()
