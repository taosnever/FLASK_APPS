#! /bin/bash
wget -O xml/aemet.xml http://www.aemet.es/xml/municipios_h/localidad_h_08019.xml