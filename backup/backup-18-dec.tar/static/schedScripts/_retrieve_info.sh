#! /bin/bash
wget -O /home/www/flask_project/static/xml/aemet.xml http://www.aemet.es/xml/municipios_h/localidad_h_08187.xml
