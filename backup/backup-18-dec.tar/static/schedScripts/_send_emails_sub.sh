#! /bin/bash
curl http://fearow.fib.upc.es/En2kxx9P46q66bayBAbdXSP3X6I6QtixyQE6ZVknrT4/hxA+oZTu1ilWtHH0N8dG
